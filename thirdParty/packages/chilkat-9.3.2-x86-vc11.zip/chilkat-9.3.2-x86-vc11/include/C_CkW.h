#ifndef _Ck_W_H
#define _Ck_W_H
#include "Chilkat_C.h"

HCkW CkW_Create(void);
void CkW_Dispose(HCkW handle);
#endif
